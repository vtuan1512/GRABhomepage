package vn.edu.usth.testview.homepage;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import vn.edu.usth.testview.R;

public class BestSellerAdapter extends RecyclerView.Adapter<BestSellerAdapter.BestSellerViewHolder> {
    private List<BestSeller> mListBestSeller;
    private IClickAddToCartListener iClickAddToCartListener;

    public interface IClickAddToCartListener{
        void OnClickAddToCart(ImageView imgAddCartBestSeller,BestSeller bestSeller);
    }
    public void setData (List<BestSeller> list,IClickAddToCartListener listener){
        this.mListBestSeller = list;
        this.iClickAddToCartListener = listener;
        notifyDataSetChanged();
    }


    @NonNull
    @Override
    public BestSellerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_best_seller, parent,false);
        return new BestSellerViewHolder(view);

    }

    @Override
    public void onBindViewHolder(@NonNull BestSellerViewHolder holder, int position) {
        BestSeller bestSeller = mListBestSeller.get(position);
        if(bestSeller ==null){
            return;
        }
        holder.imgBestSeller.setImageResource(bestSeller.getResourceId());
        holder.tvBestSellerName.setText(bestSeller.getName());
        holder.tvBestSellerDescription.setText(bestSeller.getDescription());
        holder.imgAddCartBestSeller.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!bestSeller.isAddToCart()) {
                    iClickAddToCartListener.OnClickAddToCart(holder.imgAddCartBestSeller, bestSeller);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        if (mListBestSeller !=null){
            return mListBestSeller.size();
        }
        return 0;
    }

    public class BestSellerViewHolder extends RecyclerView.ViewHolder{
        private ImageView imgBestSeller;
        private TextView tvBestSellerName;
        private TextView tvBestSellerDescription;
        private ImageView imgAddCartBestSeller;
        public BestSellerViewHolder(@NonNull View itemView) {
            super(itemView);
            imgBestSeller = itemView.findViewById(R.id.img_best_seller);
            tvBestSellerName = itemView.findViewById(R.id.tv_best_seller_name);
            tvBestSellerDescription = itemView.findViewById(R.id.tv_description_best_seller);
            imgAddCartBestSeller = itemView.findViewById(R.id.img_add_cart_best_seller);
        }
    }
}
